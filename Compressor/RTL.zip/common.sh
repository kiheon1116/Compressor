#!/bin/bash

RUN_DIR=output

COMPILE_CMD='vcs'
COMPILE_OPTIONS='-full64 -debug_access+all -kdb -LDFLAGS -Wl,--no-as-needed'

SIM_OPTIONS=''

VERDI_CMD='Verdi-SX'
VERDI_OPTIONS=''

DC_CMD='dc_shell-xg-t'
DC_OPTIONS=''

LIB_PATH=/media/2/LogicLibraries

